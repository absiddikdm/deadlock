<?php
$hostname = 'localhost';
$hostuser= 'root';
$hostpassword='';
$db_name='iawd2302';

$db_connect = mysqli_connect($hostname,$hostuser,$hostpassword,$db_name);




?>