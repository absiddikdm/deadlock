<?php
if(!isset($_SESSION['login_korche'])){
	header('location:login.php');
}
?>

